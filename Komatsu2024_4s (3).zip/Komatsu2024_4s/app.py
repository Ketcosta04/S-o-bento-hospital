from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = "hospital_secret"

DATABASE = "database.db"

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/apresentacao")
def apresentacao():
    return render_template("apresentacao.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username == "admin" and password == "admin123":
            return redirect(url_for("cadastro"))
        else:
            flash("Usuário ou senha inválidos!")
    return render_template("login.html")

@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if request.method == "POST":
        nome = request.form["nome"]
        idade = request.form["idade"]
        endereco = request.form["endereco"]
        conn = get_db_connection()
        conn.execute("INSERT INTO pacientes (nome, idade, endereco) VALUES (?, ?, ?)",
                     (nome, idade, endereco))
        conn.commit()
        conn.close()
        flash("Paciente cadastrado com sucesso!")
        return redirect(url_for("cadastro"))
    return render_template("cadastro.html")

@app.route("/consulta")
def consulta():
    conn = get_db_connection()
    pacientes = conn.execute("SELECT * FROM pacientes").fetchall()
    conn.close()
    return render_template("consulta.html", pacientes=pacientes)

if __name__ == "__main__":
    with get_db_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS pacientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                idade INTEGER NOT NULL,
                endereco TEXT NOT NULL
            )
        """)
    app.run(debug=True)




